package pkg4;

public class Calculaton {
	public int addition(int num1, int num2) {
		return num1+num2;
	}
}
