package com.learn.quiz.customException;

public class InfoMessage extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3772840913500662875L;

	public InfoMessage(String message) {
		super(message);
	}

}
