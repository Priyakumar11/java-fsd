package com.spexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstSpringbootProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstSpringbootProject1Application.class, args);
	}

}
