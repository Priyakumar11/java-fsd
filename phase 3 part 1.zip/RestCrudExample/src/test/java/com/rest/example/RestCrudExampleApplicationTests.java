package com.rest.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
